INSERT INTO `configuracion` (`id`, `is_cerrado`) VALUES
(1, b'1');

-- la contraseña es: arteaga71 para todos los usuarios
INSERT INTO `usuario` (`es_juez`, `fecha_nacimiento`, `id`, `apellidos`, `email`, `nombre`, `password`) VALUES
(NULL, '2001-02-10', 1, 'admin', 'admin@admin.es', 'admin', '$2a$15$cKOvSg.LMZVHR3Dc3xAjROsD0DNL3vF0dlWODjRVJogp0x9sRU9Xy'),
(b'1', '2001-02-10', 9, 'test1', 'test@test.es', 'test1', '$2a$15$fsnN.cKQUGxbP8mUZrQcZem6aqc2dEGtuxGFcoz8VYKyjb5/hocHW'),
(b'0', '2001-02-10', 10, 'test2', 'test2@test.es', 'test2', '$2a$15$aPJEGTwkaTWnq3srmQ7YV.rmhYF0g.pKFc2fzXzR8fk1YR.tfel5m');

INSERT INTO `concursante` (`id`, `usuario_id`) VALUES
(5, 10);

INSERT INTO `juez` (`puede_validar`, `id`, `usuario_id`) VALUES
(b'0', 6, 9);